-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 19. Nopember 2020 jam 09:49
-- Versi Server: 5.1.41
-- Versi PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_arsip`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dokuments`
--

CREATE TABLE IF NOT EXISTS `dokuments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_file` varchar(150) NOT NULL,
  `deskripsi` varchar(250) NOT NULL,
  `user_id` varchar(150) NOT NULL,
  `file` varchar(255) NOT NULL,
  `kode_folder` varchar(50) NOT NULL,
  `created_at_file` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode_folder` (`kode_folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `dokuments`
--

INSERT INTO `dokuments` (`id`, `title_file`, `deskripsi`, `user_id`, `file`, `kode_folder`, `created_at_file`) VALUES
(1, 'Coba submit', 'Di submit ', '1', 'Laporan_Oktober3.docx', '20111341', '2020-11-16 13:40:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `folder`
--

CREATE TABLE IF NOT EXISTS `folder` (
  `kode_folder` varchar(150) NOT NULL,
  `title` varchar(250) NOT NULL,
  `user_id` varchar(250) NOT NULL,
  `user_view` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`kode_folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `folder`
--

INSERT INTO `folder` (`kode_folder`, `title`, `user_id`, `user_view`, `created_at`) VALUES
('20111350', 'Folder dua', '1', '3,2', '2020-11-13 14:13:27'),
('20111341', 'Coba input', '1', '3', '2020-11-13 13:58:27'),
('20111321', 'Folder Tiga', '1', '3,2', '2020-11-13 14:15:30'),
('20111311', 'Folder Empat', '1', '3,2', '2020-11-13 14:15:37'),
('20111318', 'Folder Lima', '1', '3,2', '2020-11-13 14:15:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `password` varchar(250) NOT NULL,
  `hak_akses` enum('Staff','Ketua','Admin') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `hak_akses`) VALUES
(1, 'Efri', 'a4c5aa19cf8ac90a47440f491d197401', 'Staff'),
(2, 'Admin', 'fcea920f7412b5da7be0cf42b8c93759', 'Admin'),
(3, 'Hidayat', '37f3c4ac0ecd4a50c7f7ea1bd2b017c7', 'Staff');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
