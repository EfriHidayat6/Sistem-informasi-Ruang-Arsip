<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    function __construct(){
        parent::__construct();	
        $this->load->model('M_Login');	
        $this->load->library('session');
    }
	public function index()
	{
		$this->load->view('Login_folder/index');
    }
    public function Cek_login()
    {
        $username = $this->input->post("username", TRUE);
        $password = MD5($this->input->post('password', TRUE)); 
    $cek = $this->M_Login->Action_Cek_Login('user',array('username' => $username), array('password' => $password));
    if ($cek>0){
    foreach ($cek as $apps) {

        $session_data = array(
            'user_id' => $apps->user_id,
            'username'   => $apps->username,
            'password' => $apps->password,
            'hak_akses' => $apps->hak_akses,
        );
        $hak_akses=$apps->hak_akses;
        //set session userdata
        $this->session->set_userdata($session_data);
        echo $this->session->set_flashdata('message','success');
        echo $this->session->set_flashdata('msg','Berhasil Login');
            if($hak_akses == 'Staff'){
        redirect('Home/index','refresh');        
            }if ($hak_akses == 'Admin' ){
        redirect('Admin/index','refresh');}
        }
        }else{
        echo $this->session->set_flashdata('message','danger');
        echo $this->session->set_flashdata('msg','Username / Password Salah');
        redirect('Login/index','refresh');
         }
}
}
