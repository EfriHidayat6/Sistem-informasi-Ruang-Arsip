<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
  function __construct() {
        parent::__construct();
        $this->load->model('M_Folder');
        $this->load->model('M_Dokumen');
        $this->load->model('M_User');
        $this->load->model('M_Login');
        $hak_akses=$this->session->userdata("hak_akses");
        if($hak_akses != "Admin" )
        {
          redirect("Login/index");
        }
        if($this->M_Login->logged_id())
        {
        }else{
            redirect("Login/index");
        }
      }
	public function index()
	{
		$this->load->view('Admin_f/index');
    }
    public function Add_user()
    {
        $this->load->view('Admin_f/Form_User');
    }
    public function Save_user()
    {
        $username = $_POST['username'];
        $sql = "SELECT count(username) as hasil From user Where username='$username'";
        $query = $this->db->query($sql);
        foreach($query->result() as $v_data);
        if($v_data->hasil == 0){
        $data=array(
                    'user_id'=>'',
                    'username'=>$_POST['username'],
                    'password'=>md5($_POST['password']),
                    'hak_akses'=>$_POST['hak_akses'],
                    );
        $alert = $this->M_User->Save($data);
                }
        if($v_data->hasil > 0)
        {
        $alert = 1 ;
        }
        if($alert<1){
            echo $this->session->set_flashdata('message','success');
            echo $this->session->set_flashdata('msg','User '.$_POST['username'].' Berhasil Disimpan');
        }
        else{
            echo $this->session->set_flashdata('message','danger');
            echo $this->session->set_flashdata('msg','User '.$_POST['username'].' Gagal Disimpan / Username tidak boleh sama');
		}
		redirect('Admin/Add_user','refresh');
    }
    public function User()
    {
    $data['item_user'] = $this->M_User->Get_user();
    $this->load->view('Admin_f/V_user',$data);
    }
    public function Tampil_folder_user($user_id)
    {
    $sql = "Select * from folder where user_id='$user_id'";
    $query = $this->db->query($sql);
    $data['item_berkas'] = $query;
    $data['user_id'] = $user_id;
    $this->load->view('Admin_f/View_file_user',$data);
    }
    public function File_user($user_id,$kode_folder)
    {
    $data['item_file'] = $this->M_Dokumen->Ambildata_user($kode_folder);
    $sql = "Select * from folder where kode_folder='$kode_folder'";
    $query = $this->db->query($sql);
    foreach($query->result() as $tampil);
    $data['user'] = $tampil->user_id;
    $data['item_berkas'] = $query;
    $data['kode_folder'] = $kode_folder;
    $data['user_id'] = $user_id;
    $this->load->view('Admin_f/View_file',$data);
    }
    public function Profile_user($user_id)
    {
    $data['item_profile'] = $this->M_User->Get_Detail_user($user_id);
    return $this->load->view('Admin_f/V_Profile',$data);
    }
    public function Update_profile_user()
    {
    $user = $_POST['user_id'];
    $data = array('password'=>md5($_POST['password']));
    $alert = $this->M_User->Update_pw($data,$user);
    if($alert<1){
      echo $this->session->set_flashdata('message','success');
      echo $this->session->set_flashdata('msg','Password Berhasil Diupdate');
    }
      else{
          echo $this->session->set_flashdata('message','danger');
          echo $this->session->set_flashdata('msg','Password Gagal Diupdate');
    }
    redirect('Admin/Profile_user/'.$user,'refresh');
    }
    public function Update_jabatan_user()
    {
    $user = $_POST['user_id'];
    $data = array('hak_akses'=>$_POST['hak_akses']);
    $alert = $this->M_User->Update_hak_akses($data,$user);
    if($alert<1){
      echo $this->session->set_flashdata('message','success');
      echo $this->session->set_flashdata('msg','Jabatan Berhasil Diupdate');
    }
      else{
          echo $this->session->set_flashdata('message','danger');
          echo $this->session->set_flashdata('msg','Jabatan Gagal Diupdate');
    }
    redirect('Admin/Profile_user/'.$user,'refresh');
    }
    public function Profile()
    {
        $user_id = $this->session->userdata("user_id");
        $data['item_profile'] = $this->M_User->Get_Detail_user($user_id);
        return $this->load->view('Admin_f/V_Profile',$data);
    }
    public function Laporan_harian($tgl='')
    {
    date_default_timezone_set("Asia/Bangkok");
    if($tgl==''){
    $date = date('Y-m-d');
    }if($tgl!=''){
    $date = $tgl;
    }
    $sql = "Select * from dokuments JOIN user ON ( user.user_id = dokuments.user_id ) where substring(created_at_file,1,10)='$date'";
    $data['item_file'] = $this->db->query($sql);
    $data['tgl'] = $date;
    $this->load->view('Admin_f/Lap_Harian',$data);
    }
    public function Logout(){
        $this->session->sess_destroy();
        redirect('Login','refresh');
      }
}