<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
  function __construct() {
        parent::__construct();
        $this->load->model('M_Folder');
        $this->load->model('M_Dokumen');
        $this->load->model('M_User');
        $this->load->model('M_Login');
        $hak_akses=$this->session->userdata("hak_akses");
        if($hak_akses != "Staff" )
        {
          redirect("Login/index");
        }
        if($this->M_Login->logged_id())
        {
        }else{
            //jika session belum terdaftar, maka redirect ke halaman login
            redirect("Login/index");
        }
      }
	public function index()
	{
		$this->load->view('User/index');
  }
  public function Add_folder()
  {
    $data['item_user'] = $this->M_User->Get_user();
    $this->load->view('User/Form_folder',$data);
  }
  public function Simpan_folder()
  {
    date_default_timezone_set("Asia/Bangkok");
    $user = $this->session->userdata("user_id");
    $tgl_buat = date('Y-m-d H:i:s');
    $tgl = date('ymd');
    $rand = rand(10, 2000);
    $check = $_POST['check_list'];
    $data_satu = implode(",",$check);
    $data = array(
            'kode_folder'=>$user.$tgl.$rand,
            'title'=>$_POST['title'],
            'user_id'=>$user,
            'user_view'=>$data_satu,
            'created_at'=>$tgl_buat
            );
    $alert = $this->M_Folder->Save($data);
		if($alert<1){
            echo $this->session->set_flashdata('message','success');
            echo $this->session->set_flashdata('msg','Folder '.$_POST['title'].' Berhasil Disimpan');
        }
        else{
            echo $this->session->set_flashdata('message','danger');
            echo $this->session->set_flashdata('msg','Folder '.$_POST['title'].' Gagal Disimpan');
		}
		redirect('Home/Add_folder','refresh');
  }
  public function Folder()
  {
    $user = $this->session->userdata("user_id");
    $data['item_berkas'] = $this->M_Folder->Ambildata($user);
    $this->load->view('User/View_folder',$data);
  }
  public function File()
  {
    $user = $this->session->userdata("user_id");
    $data['item_file'] = $this->M_Dokumen->Get_file($user);
    $this->load->view('User/V_File',$data);
  }
  public function Tampil_folder($kode_folder)
  {
    $user = $this->session->userdata("user_id");
    $data['item_file'] = $this->M_Dokumen->Ambildata($kode_folder,$user);
    $data['item_berkas'] = $this->M_Folder->Detailfolder($kode_folder,$user);
    $data['kode_folder'] = $kode_folder;
    $this->load->view('User/View_file',$data);
  }
  public function Add_file()
  {
    $user = $this->session->userdata("user_id");
    $data['item_berkas'] = $this->M_Folder->Ambildata($user);
    $this->load->view('User/Form_file',$data);
  }
  public function Simpan_file()
  {
    date_default_timezone_set('Asia/Jakarta');
    $this->load->library('upload');
		$config['upload_path'] 		= './assets/file/';
		$config['allowed_types']        = 'doc|docx|png|jpeg|jpg|pdf|zip|rar';
    $config['max_size']             = '204800';
    $this->load->library('upload', $config);
    $this->upload->initialize($config);
    if(!$this->upload->do_upload('file')){
			$this->upload->display_errors();
		}else{
    $datax = $this->upload->data();
    $date = date('Y-m-d H:i:s');
    $data=array(
					'title_file'=>$_POST['title_file'],
          'deskripsi'=>$_POST['deskripsi'],
          'user_id'=>'0',
					'file'=>$datax['file_name'],
          'kode_folder'=>$_POST['kode_folder'],
          'created_at_file'=> $date
        );
    $alert = $this->M_Dokumen->Save($data);
    if($alert<1){
      echo $this->session->set_flashdata('message','success');
      echo $this->session->set_flashdata('msg','Folder '.$_POST['title_file'].' Berhasil Disimpan');
    }
      else{
          echo $this->session->set_flashdata('message','danger');
          echo $this->session->set_flashdata('msg','Folder '.$_POST['title_file'].' Gagal Disimpan');
    }
    redirect('Home/Add_file','refresh');
  }
  }
  public function Add_viewer($kode_folder)
  {
    $user = $this->session->userdata("user_id");
    $data['item_berkas'] = $this->M_Folder->Detailfolder($kode_folder,$user);
    $data['item_user'] = $this->M_User->Get_user();
    $data['kode_folder'] = $kode_folder;
    $this->load->view('User/Form_view',$data);
  }
  public function Update_viewer()
  {
    $check = $_POST['check_list'];
    $data_satu = implode(",",$check);
    $data = array(
            'user_view'=>$data_satu,
    );
    $key = $_POST['kode_folder'];
    $alert = $this->M_Folder->Update_view($data,$key);
    if($alert<1){
      echo $this->session->set_flashdata('message','danger');
      echo $this->session->set_flashdata('msg','Folder '.$key.' Gagal DiUpdate');
    }
      else{
      echo $this->session->set_flashdata('message','success');
      echo $this->session->set_flashdata('msg','Folder '.$key.' Berhasil DiUpdate');
    }
    redirect('Home/Tampil_folder/'.$key,'refresh');
  }
  public function User()
  {
    $user = $this->session->userdata("user_id");
    $data['item_user'] = $this->M_User->Get_user_data($user);
    $this->load->view('User/V_user',$data);
  }
  public function Tampil_folder_user($user_id)
  {
    $user = $this->session->userdata("user_id");
    $sql = "Select * from folder where user_id='$user_id' and user_view LIKE '%$user%' ";
    $query = $this->db->query($sql);
    $data['item_berkas'] = $query;
    $this->load->view('User/View_file_user',$data);
  }
  public function File_user($kode_folder)
  {
    $user = $this->session->userdata("user_id");
    $data['item_file'] = $this->M_Dokumen->Ambildata_user($kode_folder);
    $sql = "Select * from folder where kode_folder='$kode_folder' and user_view LIKE '%$user%' ";
    $query = $this->db->query($sql);
    foreach($query->result() as $tampil);
    $data['user'] = $tampil->user_id;
    $data['item_berkas'] = $query;
    $data['kode_folder'] = $kode_folder;
    $this->load->view('User/View_file',$data);
  }
  public function Laporan_harian($tgl='')
  {
    date_default_timezone_set("Asia/Bangkok");
    if($tgl==''){
    $date = date('Y-m-d');
    }if($tgl!=''){
    $date = $tgl;
    }
    $sql = "Select * from dokuments JOIN user ON ( user.user_id = dokuments.user_id ) where substring(created_at_file,1,10)='$date'";
    $data['item_file'] = $this->db->query($sql);
    $data['tgl'] = $date;
    $this->load->view('User/Lap_Harian',$data);
  }
  public function Profile()
  {
    $user = $this->session->userdata("user_id");
    $data['item_profile'] = $this->M_User->Get_Detail_user($user);
    return $this->load->view('User/V_Profile',$data);
  }
  public function Update_profile()
  {
    $user= $this->session->userdata("user_id");
    $data = array('password'=>md5($_POST['password']));
    $alert = $this->M_User->Update_pw($data,$user);
    if($alert<1){
      echo $this->session->set_flashdata('message','success');
      echo $this->session->set_flashdata('msg','Password Berhasil Diupdate');
    }
      else{
          echo $this->session->set_flashdata('message','danger');
          echo $this->session->set_flashdata('msg','Password Gagal Diupdate');
    }
    redirect('Home/Profile','refresh');
  }
  public function Logout(){
    $this->session->sess_destroy();
    redirect('Login','refresh');
  }
}
