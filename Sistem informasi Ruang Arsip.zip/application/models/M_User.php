<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_User extends CI_Model
{
    function Get_user()
    {
        return $this->db->get('user');
    }
    function Get_user_data($user)
    {
        $this->db->where('user_id !=',$user);
        return $this->db->get('user');
    }
    function Get_Detail_user($user)
    {
        $this->db->where('user_id',$user);
        return $this->db->get('user');
    }
    function Update_pw($data,$user)
    {
        $this->db->where('user_id',$user);
        $this->db->update('user',$data);
    }
    function Save($data)
    {
        $this->db->insert('user',$data);
    }
    function Update_hak_akses($data,$user)
    {
        $this->db->where('user_id',$user);
        $this->db->update('user',$data);
    }
}