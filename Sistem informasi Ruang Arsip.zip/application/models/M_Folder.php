<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Folder extends CI_Model
{
    function Save($data)
    {
        $this->db->insert('folder',$data);
    }
    function Ambildata($user)
    {
        $this->db->where('user_id',$user);
        return $this->db->get('folder');
    }
    
    function Detailfolder($kode_folder,$user)
    {
        $this->db->where('kode_folder',$kode_folder);
        $this->db->where('user_id',$user);
        $this->db->limit(1);
        return $this->db->get('folder');
    }
    function Update_view($data,$key)
    {
        $this->db->where('kode_folder',$key);
        return $this->db->update('folder',$data);
    }
    function Get_folder($user_id)
    {
        $this->db->where('user_id',$user_id);
        return $this->db->get('folder');
    }
}