<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_Dokumen extends CI_Model
{
    function Ambildata($kode_folder,$user)
    {
        $this->db->where('kode_folder',$kode_folder);
        $this->db->where('user_id',$user);
        return $this->db->get('dokuments');
    }
    function Save($data)
    {
        $this->db->insert('dokuments',$data);
    }
    function Get_file($user)
    {
        $this->db->where('user_id',$user);
        return $this->db->get('dokuments');
    }
    function Ambildata_user($kode_folder)
    {
        $this->db->where('kode_folder',$kode_folder);
        return $this->db->get('dokuments');
    }
}