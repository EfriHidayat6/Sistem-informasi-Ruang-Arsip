<?php include 'assets/Layout/temp_admin.php' ?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add User</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Add User</li>
            </ol>
          </div>
          <?php if ($this->session->flashdata('message')) { ?>
                  <div class="alert alert-<?php echo $this->session->flashdata('message');  ?> alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $this->session->flashdata('msg');  ?>
                  </div>
          <?php } ?>
          <div class="row">
            <div class="col-lg-6">
              <div class="card mb-4">
                <div class="card-body">
                <h6 class="m-0 font-weight-bold text-primary">Add User</h6>
                    <form name="save" method="post" name="save" action="<?php echo base_url()?>Admin/Save_user">
                    <div class="form-group">
                      <label for="">Username</label>
                      <input type="text" class="form-control" name='username' id="username" placeholder="" required='required'>
                    </div>
                    <div class="form-group">
                      <label for="">Password</label>
                      <input type="text" name="password" class="form-control" required='required' minlength="6" placeholder="">
                    </div>
                    <div class="form-group">
                      <label for="">Password</label>
                      <select name="hak_akses" class="form-control" required='required'>
                      <option value="Staff">Staff</option>
                      <option value="Admin">Admin</option>
                      </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php include 'assets/Layout/footer.php' ?>