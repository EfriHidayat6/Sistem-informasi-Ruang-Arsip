<?php include 'assets/Layout/temp_admin.php' ?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Folder</li>
            </ol>
          </div>
          <h6 class="m-0 font-weight-bold text-primary">
            <i class="fa fa-arrow-left"></i><a href="<?php echo base_url()?>Admin/User"> Kembali</a> 
            </h6> <br>
        <div class="row mb-3">
            <?php foreach($item_berkas->result() as $v_data) { ?>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo $v_data->title ?></div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-calendar"></i> <?php echo $v_data->created_at ?></span>
                      </div>
                    </div>
                    <a href='<?php echo base_url() ?>Admin/File_user/<?php echo $user_id ?>/<?php echo $v_data->kode_folder ?>'>
                    <div class="col-auto">
                      <i class="fas fa-folder-open fa-2x text-primary"></i>
                    </div>
                    </a>
                  </div>
                </div>
                
              </div>
            </div>
            <?php } ?>
        </div>  
    </div>
    <?php include 'assets/Layout/footer.php' ?>