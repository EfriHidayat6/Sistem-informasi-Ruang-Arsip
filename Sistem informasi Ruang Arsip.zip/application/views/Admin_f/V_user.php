<?php include 'assets/Layout/temp_admin.php' ?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">User</li>
            </ol>
          </div>

        <div class="row mb-3">
            <?php foreach($item_user->result() as $v_data) { ?>
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo $v_data->username ?></div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-user-edit"></i> <a href="<?php echo base_url()?>Admin/Profile_user/<?php echo $v_data->user_id ?>">Update Profile</a>  </span>
                      </div>
                    </div>
                    <a href='<?php echo base_url() ?>Admin/Tampil_folder_user/<?php echo $v_data->user_id ?>'>
                    <div class="col-auto">
                      <i class="fas fa-user fa-2x text-primary"></i>
                    </div>
                    </a>
                  </div>
                </div>
                
              </div>
            </div>
            <?php } ?>
        </div>  
    </div>
    <?php include 'assets/Layout/footer.php' ?>