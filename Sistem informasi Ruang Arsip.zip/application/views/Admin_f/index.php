<?php include 'assets/Layout/temp_admin.php' ?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
          </div>
          <?php if ($this->session->flashdata('message')) { ?>
                  <div class="alert alert-<?php echo $this->session->flashdata('message');  ?> alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $this->session->flashdata('msg');  ?>
                  </div>
          <?php } ?>
          <div class="row mb-12">
          <div class="col-xl-12 col-md-12 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span>Selamat datang <?php echo $this->session->userdata("username")?> , Semoga sistem ini dapat memudahkan segala pengumpulan berkas dan pengarsipan file anda.</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
          </div>

          <div class="row mb-3">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">From User</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">From User</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span>Tambah User</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <a href="<?php echo base_url()?>Admin/Add_user"><i class="fas fa-user fa-2x text-primary"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- New User Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">User</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">User</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span>File User</span>
                      </div>
                    </div>
                    <div class="col-auto">
                    <a href="<?php echo base_url()?>Admin/User"><i class="fas fa-users fa-2x text-info"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Earnings (Annual) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Profile</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">Profile</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span>Profile Anda</span>
                      </div>
                    </div>
                    <div class="col-auto">
                    <a href="<?php echo base_url()?>Admin/Profile"><i class="fas fa-key fa-2x text-success"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Pelaporan Harian</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">Pelaporan Harian</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span>Pelaporan Harian</span>
                      </div>
                    </div>
                    <div class="col-auto">
                    <a href="<?php echo base_url()?>Admin/Laporan_harian"><i class="fas fa-print fa-2x text-warning"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php include 'assets/Layout/footer.php' ?>