<?php include 'assets/Layout/temp_user.php' ?>

        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Profile</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Profile</li>
            </ol>
          </div>
          <?php if ($this->session->flashdata('message')) { ?>
                  <div class="alert alert-<?php echo $this->session->flashdata('message');  ?> alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $this->session->flashdata('msg');  ?>
                  </div>
          <?php } ?>
          <?php foreach($item_profile->result() as $v_data); ?>
          <div class="row">
            <div class="col-lg-6">
              <div class="card mb-4">
                <div class="card-body">
                <h6 class="m-0 font-weight-bold text-primary">Profile</h6>
                  <form name='simpan' method='post' action='<?php echo base_url(); ?>Home/Update_profile'>
                    <div class="form-group">
                      <label for="">Username</label>
                      <input type="text" class="form-control" name='title' id="title" value="<?php echo $v_data->username ?>" readonly>
                    </div>
                    <div class="form-group">
                      <label for="">Ganti Password</label>
                      <input type="text" class="form-control" name='password' id="password" value="" required='required' minlength="6">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php include 'assets/Layout/footer.php' ?>