<?php include 'assets/Layout/temp_user.php' ?>

        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add Viewer</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Add Viewer</li>
            </ol>
          </div>
          <?php if ($this->session->flashdata('message')) { ?>
                  <div class="alert alert-<?php echo $this->session->flashdata('message');  ?> alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $this->session->flashdata('msg');  ?>
                  </div>
          <?php } ?>
          <div class="row">
            <div class="col-lg-6">
              <div class="card mb-4">
                <div class="card-body">
                <h6 class="m-0 font-weight-bold text-primary">Add Viewer</h6>
                  <form name='simpan' method='post' action='<?php echo base_url(); ?>Home/Update_viewer'>
                  <div class="form-group">
                      <label for="">Nama Folder </label>
                    <?php foreach($item_berkas->result() as $v_berkas ); ?>
                    <input type="hidden" name="kode_folder" class="form-control" value="<?php echo $kode_folder ?>" readonly>
                    <input type="text" class="form-control" value="<?php echo $v_berkas->title ?>" readonly>
                    </div>
                    <div class="form-group">
                      <label for="">Nama Viewer </label> <br>
                      <?php foreach($item_user->result() as $v_user) { ?>
                        <input type="checkbox" name="check_list[]" alt="Checkbox" value="<?php echo $v_user->user_id ?>"> <?php echo $v_user->username ?> &nbsp;
                      <?php } ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php include 'assets/Layout/footer.php' ?>