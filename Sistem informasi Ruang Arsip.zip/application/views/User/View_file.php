        <?php include 'assets/Layout/temp_user.php';
        error_reporting(0);
        ?>
        <div class="container-fluid" id="container-wrapper">
        <?php if ($this->session->flashdata('message')) { ?>
                  <div class="alert alert-<?php echo $this->session->flashdata('message');  ?> alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $this->session->flashdata('msg');  ?>
                  </div>
          <?php } ?>
            <?php foreach($item_berkas->result() as $v_berkas); ?>
        <div class="row">
            <div class="col-lg-12">
            <div class="card mb-4">
            <div class="table-responsive p-3">
            <h6 class="m-0 font-weight-bold text-primary">
            <i class="fa fa-search"></i> Dapat Dilihat Juga Oleh :
           </h6> 
           <i class="fa fa-arrow-right"></i> 
            <?php 
            $teks = $v_berkas->user_view;
            $urai = explode(",",$teks);
            ?>
            <b>
                <?php foreach ($urai as $key => $data){ ?>
                        <?php 
                        $Sql = "SELECT * From user WHERE user_id='$data'";
                        $dat = $this->db->query($Sql);
                        foreach($dat->result() as $v_user);
                        ?>
                        <i class="fa fa-user"></i><font color="red"> <?php echo $v_user->username ?> &nbsp; </font>
                <?php } ?>
            </b>
            <h6 class="m-0 font-weight-bold text-primary">
            <?php 
            $user_view = $this->session->userdata("user_id");
            if($v_berkas->user_id == $user_view) {
            ?>
            <i class="fa fa-plus"></i> Update Viewer : <a href="<?php echo base_url() ?>Home/Add_viewer/<?php echo $kode_folder ?>" >
            <i class="fa fa-user-plus"></i> Update Viewer</a>
            
            <?php } ?>
           </h6>
           </div>
           </div>
           </div>
            <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">
                    <a href="<?php echo base_url() ?>Home/Folder"><i class="fa fa-arrow-left"></i></a> Data File <?php echo $v_berkas->title ?> &nbsp; 
            <?php if($v_berkas->user_id == $user_view) { ?><a href="<?php echo base_url() ?>Home/Add_file"><i class="fa fa-plus"></i> <i class="fa fa-file"></i></a><?php } ?></h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush" id="dataTable">
                    <thead class="thead-light">
                      <tr>
                        <th>Title</th>
                        <th>Deskripsi</th>
                        <th>File</th>
                        <th>Tanggal Diunggah</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php foreach($item_file->result() as $v_file) 
                        { ?>  
                      <tr>
                        <td><i class='fa fa-file'></i> <?php echo $v_file->title_file ?></td>
                        <td><?php echo $v_file->deskripsi ?></td>
                        <td><a href="<?php echo base_url();?>assets/file/<?php echo $v_file->file ?>"><i class="fa fa-download"></i> <?php echo $v_file->file ?></a></td>
                        <td><?php echo $v_file->created_at_file ?></td>
                      </tr>
                        <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
        </div>
        </div>
        <?php include 'assets/Layout/footer.php' ?>