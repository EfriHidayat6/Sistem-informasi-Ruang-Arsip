<?php include 'assets/Layout/temp_user.php' ?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add File</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item">Add File</li>
            </ol>
          </div>
          <?php if ($this->session->flashdata('message')) { ?>
                  <div class="alert alert-<?php echo $this->session->flashdata('message');  ?> alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    <?php echo $this->session->flashdata('msg');  ?>
                  </div>
          <?php } ?>
          <div class="row">
            <div class="col-lg-6">
              <div class="card mb-4">
                <div class="card-body">
                <h6 class="m-0 font-weight-bold text-primary">Add File</h6>
                    <?php
                    echo form_open_multipart('Home/Simpan_file');
                    ?>
                    <div class="form-group">
                      <label for="">Nama File</label>
                      <input type="text" class="form-control" name='title_file' id="title_file" placeholder="" required='required'>
                    </div>
                    <div class="form-group">
                      <label for="">Deskripsi</label>
                      <textarea class="form-control" name="deskripsi" id="deskripsi"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="">File</label>
                       <font color='red'>*doc,docx,png,jpeg,jpg,pdf,zip,rar</font>
                      <input type="file" class="form-control" name='file' id="file" required='required'>
                    </div>
                    <div class="form-group">
                      <label for="">Folder</label>
                      <select name="kode_folder" class="form-control">
                          <?php foreach($item_berkas->result() as $v_berkas) { ?>
                          <option value="<?php echo $v_berkas->kode_folder ?>"><?php echo $v_berkas->title ?></option>
                          <?php } ?>
                      </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php include 'assets/Layout/footer.php' ?>