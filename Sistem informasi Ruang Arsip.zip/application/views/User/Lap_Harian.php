<?php include 'assets/Layout/temp_user.php' ?>
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Laporan Harian</li>
            </ol>
          </div>
          <script>
            function change() {
                var tgl = document.getElementById("tgl").value;
                document.location.href = "<?php echo base_url(); ?>Home/Laporan_harian" + '/' + tgl;
            }
        </script>
        <div class="col-lg-3">
        <h6 class="m-0 font-weight-bold text-primary">Pilih Hari</h6>
                <input type='date' name='tgl' id='tgl' class='form-control mb-2' onchange='change()'>
        </div>
          <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Laporan Harian <?php echo $tgl ?></h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush" id="dataTable">
                    <thead class="thead-light">
                      <tr>
                        <th>User</th>
                        <th>Title</th>
                        <th>Deskripsi</th>
                        <th>File</th>
                        <th>Diunggah Tanggal</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php foreach($item_file->result() as $v_file) 
                        { ?>  
                      <tr>
                        <td><i class="fa fa-user-circle"></i> <?php echo $v_file->username ?></td>
                        <td><i class='fa fa-print'></i> <?php echo $v_file->title_file ?></td>
                        <td><?php echo $v_file->deskripsi ?></td>
                        <td>
                            <a href="<?php echo base_url();?>assets/file/<?php echo $v_file->file ?>"><i class="fa fa-download"></i> <?php echo $v_file->file ?></a></td>
                        <td><?php echo $v_file->created_at_file ?></td>
                      </tr>
                        <?php } ?>
</table>
</div>
</div>
</div>
    </div>
    <?php include 'assets/Layout/footer.php' ?>